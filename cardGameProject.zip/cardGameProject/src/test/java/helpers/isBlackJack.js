function isBlackjack(hand) {
  const values = {
    A: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    10: 10,
    J: 10,
    Q: 10,
    K: 10,
  };

  let sum = 0;
  let hasAce = false;

  for (let card of hand) {
    sum += values[card];
    if (card === "A") {
      hasAce = true;
    }
  }

  if (sum === 21) {
    return "Blackjack!";
  } else if (sum <= 21 && hasAce) {
    return "Blackjack or under 21 with Ace!";
  } else {
    return "Not a Blackjack.";
  }
}

package helpers;
import com.github.javafaker.Faker;

public class DataGenerator {
    
    static Faker faker = new Faker();

    public static String getRandomId() {
        String id = faker.random().nextInt(0, 10000).toString();
        return id;
    }

    public static String getRandomPetName() {
        String name = faker.cat().name();
        return name;
    }
}

function fn() {
  var env = karate.env; // get system property 'karate.env'
  karate.log("karate.env system property was:", env);
  if (!env) {
    env = "QA";
  }
  var config = {
    env: env,
    deckURL: "https://deckofcardsapi.com/",
  };
  if (env == "QA") {
    config.deckURL = "https://deckofcardsapi.com/";
  } else if (env == "Dev") {
    // customize
  } else if (env == "Staging") {
    // customize
  }
  return config;
}
